from django.apps import AppConfig


class WizardsAppConfig(AppConfig):
    name = 'wizards_app'
