from django.apps import AppConfig


class NewAppConfig(AppConfig):
    name = 'new_app'
