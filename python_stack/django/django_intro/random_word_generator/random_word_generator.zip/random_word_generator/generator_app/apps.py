from django.apps import AppConfig


class GeneratorAppConfig(AppConfig):
    name = 'generator_app'
