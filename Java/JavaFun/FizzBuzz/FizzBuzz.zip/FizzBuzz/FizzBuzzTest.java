public class FizzBuzzTest {
    public static void main(String[] args) {
        FizzBuzz fizzBuzz = new FizzBuzz();
        int number = 33;
        System.out.println(fizzBuzz.fizzBuzz(number));
    }
}