
public class GorillaTest {

	public static void main(String[] args) {
		Gorilla fred = new Gorilla();
		fred.throwSomething();
		fred.throwSomething();
		fred.throwSomething();
		fred.climb();
		fred.eatBannans();
		fred.eatBannans();
		fred.displayEnergy();
	}

}
