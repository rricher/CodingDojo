
public class BatTest {

	public static void main(String[] args) {
		Bat batty = new Bat();
		batty.attackTown();
		batty.attackTown();
		batty.attackTown();
		batty.eatHumans();
		batty.eatHumans();
		batty.fly();
		batty.fly();
	}

}
